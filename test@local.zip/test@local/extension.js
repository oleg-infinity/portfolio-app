import St from 'gi://St';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';

export default class PortfolioExtension {
    constructor() {
        this._button = null;
        this._window = null;
        this._isWindowVisible = false;
        this._assetsData = [];
        this._dataFile = null;
        this._isEditMode = false;
        this._suggestionsWindow = null;
        this._priceUpdateInterval = null;
        this._currentHoverIndex = -1;
        this._chartAnimationProgress = 0;
    }

    enable() {
        this._initDataStorage();
        this._loadAssetsData();
        this._createPanelButton();
        
        this._priceUpdateInterval = GLib.timeout_add_seconds(
            GLib.PRIORITY_DEFAULT,
            300,
            () => {
                this._updateAssetPrices();
                return GLib.SOURCE_CONTINUE;
            }
        );
    }

    _initDataStorage() {
        try {
            const userConfigDir = GLib.get_user_config_dir();
            const portfolioDir = `${userConfigDir}/portfolio-tracker`;
            
            if (!GLib.file_test(portfolioDir, GLib.FileTest.EXISTS)) {
                GLib.mkdir_with_parents(portfolioDir, 0o755);
            }
            
            this._dataFile = `${portfolioDir}/portfolio.json`;
            
        } catch (e) {
            log(`Storage init error: ${e}`);
            const homeDir = GLib.get_home_dir();
            this._dataFile = `${homeDir}/.portfolio-tracker.json`;
        }
    }

    _loadAssetsData() {
        try {
            if (GLib.file_test(this._dataFile, GLib.FileTest.EXISTS)) {
                const [success, contents] = GLib.file_get_contents(this._dataFile);
                if (success) {
                    const decoder = new TextDecoder('utf-8');
                    const jsonString = decoder.decode(contents);
                    const data = JSON.parse(jsonString);
                    this._assetsData = data.assets || [];
                }
            } else {
                this._assetsData = [];
                this._saveAssetsData();
            }
        } catch (e) {
            log(`Data load error: ${e}`);
            this._assetsData = [];
        }
    }

    _saveAssetsData() {
        try {
            const data = {
                version: '2.0',
                lastUpdate: new Date().toISOString(),
                assets: this._assetsData
            };
            
            const encoder = new TextEncoder();
            const jsonString = JSON.stringify(data, null, 2);
            const bytes = encoder.encode(jsonString);
            
            GLib.file_set_contents(this._dataFile, bytes);
        } catch (e) {
            log(`Data save error: ${e}`);
        }
    }

    _createPanelButton() {
        this._button = new PanelMenu.Button(0.0, 'PortfolioTracker', false);
        this._button.add_style_class_name('portfolio-panel-button');
        
        this._portfolioIcon = new St.Icon({
            gicon: new Gio.ThemedIcon({ name: 'money-manager-symbolic' }),
            style_class: 'panel-portfolio-icon'
        });
        
        this._button.add_child(this._portfolioIcon);
        
        this._button.connect('button-press-event', () => {
            this._togglePortfolioWindow();
            return Clutter.EVENT_STOP;
        });
        
        Main.panel.addToStatusArea('portfolio-tracker', this._button, 0, 'left');
    }

    _searchAsset(symbol) {
        return new Promise((resolve) => {
            if (!symbol) {
                resolve(null);
                return;
            }

            const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=1d`;
        
            try {
                const file = Gio.File.new_for_uri(url);
                const cancellable = new Gio.Cancellable();
            
                file.load_contents_async(cancellable, (file, result) => {
                    try {
                        const [success, contents] = file.load_contents_finish(result);
                    
                        if (!success) {
                            resolve(null);
                            return;
                        }
                    
                        const decoder = new TextDecoder('utf-8');
                        const responseText = decoder.decode(contents);
                        const json = JSON.parse(responseText);
                    
                        if (json.chart?.result?.[0]) {
                            const result = json.chart.result[0];
                            const meta = result.meta;
                            const price = meta.regularMarketPrice;
                        
                            if (price) {
                                resolve({
                                    symbol: meta.symbol,
                                    price: price,
                                    currentPrice: price,
                                    name: meta.shortName || meta.symbol,
                                    purchasePrice: price
                                });
                            } else {
                                resolve(null);
                            }
                        } else {
                            resolve(null);
                        }
                    } catch (e) {
                        log(`Parse error: ${e}`);
                        resolve(null);
                    }
                });
            } catch (e) {
                log(`Search error: ${e}`);
                resolve(null);
            }
        });
    }

    _searchSuggestions(query) {
        return new Promise((resolve) => {
            if (!query || query.length < 2) {
                resolve([]);
                return;
            }

            const url = `https://query1.finance.yahoo.com/v1/finance/search?q=${encodeURIComponent(query)}&lang=en-US&region=US&quotesCount=5`;
            
            try {
                const file = Gio.File.new_for_uri(url);
                const cancellable = new Gio.Cancellable();
            
                file.load_contents_async(cancellable, (file, result) => {
                    try {
                        const [success, contents] = file.load_contents_finish(result);
                    
                        if (!success) {
                            resolve([]);
                            return;
                        }
                    
                        const decoder = new TextDecoder('utf-8');
                        const responseText = decoder.decode(contents);
                        const json = JSON.parse(responseText);
                    
                        if (json.quotes) {
                            const suggestions = json.quotes
                                .filter(quote => quote.quoteType === 'EQUITY')
                                .slice(0, 5)
                                .map(quote => ({
                                    symbol: quote.symbol,
                                    name: quote.shortname || quote.longname || quote.symbol,
                                    exchange: quote.exchange
                                }));
                            resolve(suggestions);
                        } else {
                            resolve([]);
                        }
                    } catch (e) {
                        log(`Suggestions error: ${e}`);
                        resolve([]);
                    }
                });
            } catch (e) {
                log(`Suggestions search error: ${e}`);
                resolve([]);
            }
        });
    }

    _showSuggestions(suggestions) {
        this._hideSuggestions();
        
        if (suggestions.length === 0) return;
        
        this._suggestionsWindow = new St.Widget({
            style_class: 'suggestions-window',
            reactive: true
        });

        const suggestionsContainer = new St.BoxLayout({
            vertical: true,
            style_class: 'suggestions-container'
        });

        suggestions.forEach((suggestion, index) => {
            const suggestionItem = new St.Button({
                style_class: 'suggestion-item',
                reactive: true
            });

            const suggestionContent = new St.BoxLayout({
                style_class: 'suggestion-content'
            });

            const symbolLabel = new St.Label({
                text: suggestion.symbol,
                style_class: 'suggestion-symbol'
            });

            const nameLabel = new St.Label({
                text: suggestion.name,
                style_class: 'suggestion-name'
            });

            suggestionContent.add_child(symbolLabel);
            suggestionContent.add_child(nameLabel);
            suggestionItem.add_child(suggestionContent);

            // Анімація появи
            suggestionItem.opacity = 0;
            GLib.timeout_add(GLib.PRIORITY_DEFAULT, index * 50, () => {
                suggestionItem.ease({
                    opacity: 255,
                    duration: 200,
                    mode: Clutter.AnimationMode.EASE_OUT_QUAD
                });
                return GLib.SOURCE_REMOVE;
            });

            suggestionItem.connect('clicked', () => {
                this._searchEntry.set_text(suggestion.symbol);
                this._hideSuggestions();
                this._performSearchFromInput();
            });

            suggestionsContainer.add_child(suggestionItem);
        });

        this._suggestionsWindow.add_child(suggestionsContainer);
        
        const [buttonX, buttonY] = this._searchButton.get_transformed_position();
        const buttonHeight = this._searchButton.get_height();
        
        this._suggestionsWindow.set_position(buttonX, buttonY + buttonHeight + 5);
        
        Main.layoutManager.addChrome(this._suggestionsWindow);
        this._suggestionsWindow.show();
    }

    _hideSuggestions() {
        if (this._suggestionsWindow) {
            Main.layoutManager.removeChrome(this._suggestionsWindow);
            this._suggestionsWindow.destroy();
            this._suggestionsWindow = null;
        }
    }

    _setupSearchEntry() {
        let timeoutId = null;
        
        this._searchEntry.get_clutter_text().connect('text-changed', () => {
            const query = this._searchEntry.get_text().trim();
            
            if (timeoutId) {
                GLib.Source.remove(timeoutId);
            }
            
            if (query.length < 2) {
                this._hideSuggestions();
                return;
            }
            
            timeoutId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 300, () => {
                this._searchSuggestions(query).then(suggestions => {
                    if (this._searchEntry && this._searchEntry.get_parent()) {
                        this._showSuggestions(suggestions);
                    }
                });
                return GLib.SOURCE_REMOVE;
            });
        });

        this._searchEntry.get_clutter_text().connect('key-press-event', (actor, event) => {
            const key = event.get_key_symbol();
            if (key === Clutter.KEY_Escape) {
                this._hideSuggestions();
                this._toggleSearchInput();
                return Clutter.EVENT_STOP;
            }
            if (key === Clutter.KEY_Return || key === Clutter.KEY_KP_Enter) {
                this._hideSuggestions();
                this._performSearchFromInput();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });
    }

    _togglePortfolioWindow() {
        if (this._isWindowVisible) {
            this._hidePortfolioWindow();
        } else {
            this._showPortfolioWindow();
        }
    }

    _toggleEditMode() {
        this._isEditMode = !this._isEditMode;
    
        if (this._isEditMode) {
            this._editModeButton.add_style_class_name('active');
            this._editModeIcon.icon_name = 'object-select-symbolic';
        } else {
            this._editModeButton.remove_style_class_name('active');
            this._editModeIcon.icon_name = 'edit-symbolic';
            this._saveAssetsData();
        }
    
        this._updatePortfolioData();
    }

    _showPortfolioWindow() {
        if (!this._window) {
            this._createPortfolioWindow();
        }
        
        this._window.opacity = 0;
        this._window.scale_x = 0.9;
        this._window.scale_y = 0.9;
        
        Main.layoutManager.addChrome(this._window);
        this._isWindowVisible = true;
        this._updatePortfolioData();
        this._window.show();
        
        // Анімація появи
        this._window.ease({
            opacity: 255,
            scale_x: 1,
            scale_y: 1,
            duration: 300,
            mode: Clutter.AnimationMode.EASE_OUT_BACK
        });
    }

    _hidePortfolioWindow() {
        if (this._window && this._isWindowVisible) {
            this._window.ease({
                opacity: 0,
                scale_x: 0.9,
                scale_y: 0.9,
                duration: 200,
                mode: Clutter.AnimationMode.EASE_IN_BACK,
                onComplete: () => {
                    this._window.hide();
                    Main.layoutManager.removeChrome(this._window);
                    this._isWindowVisible = false;
                }
            });
        }
    }

    _performSearchFromInput() {
        const symbol = this._searchEntry.get_text().trim().toUpperCase();
        if (!symbol) return;

        this._searchAsset(symbol).then(asset => {
            if (asset) {
                this._askForPurchaseDetails(asset);
                this._toggleSearchInput();
            } else {
                Main.notify(`Asset "${symbol}" not found`);
            }
        });
    }

    _updateAssetPrices() {
        const updatePromises = this._assetsData.map(asset => {
            return this._searchAsset(asset.symbol).then(updatedAsset => {
                if (updatedAsset) {
                    asset.price = updatedAsset.price;
                    asset.currentPrice = updatedAsset.price;
                }
            }).catch(error => {
                log(`Price update error for ${asset.symbol}: ${error}`);
            });
        });

        Promise.all(updatePromises).then(() => {
            this._updatePortfolioData();
            this._saveAssetsData();
        });
    }

    _toggleSearchInput() {
        const isExpanded = this._searchButton.has_style_class_name('expanded');

        if (isExpanded) {
            this._collapseToButton();
        } else {
            this._expandToSearch();
        }
    }

    _expandToSearch() {
        this._searchButton.add_style_class_name('expanded');
        this._searchEntry.show();
        this._searchEntry.set_text('');
        this._searchIcon.icon_name = 'window-close-symbolic';
        
        this._searchEntry.opacity = 0;
        this._searchEntry.width = 0;
        
        GLib.timeout_add(GLib.PRIORITY_DEFAULT, 150, () => {
            this._searchEntry.grab_key_focus();
            this._searchEntry.ease({
                opacity: 255,
                width: 160,
                duration: 250,
                mode: Clutter.AnimationMode.EASE_OUT_QUAD
            });
            return GLib.SOURCE_REMOVE;
        });
    }

    _collapseToButton() {
        this._searchButton.remove_style_class_name('expanded');
        this._hideSuggestions();
        this._searchIcon.icon_name = 'edit-find-symbolic';
        
        this._searchEntry.ease({
            opacity: 0,
            width: 0,
            duration: 200,
            mode: Clutter.AnimationMode.EASE_IN_QUAD,
            onComplete: () => {
                this._searchEntry.hide();
                this._searchEntry.set_text('');
            }
        });
    }

    _createPortfolioWindow() {
        this._window = new St.Widget({
            style_class: 'portfolio-window',
            reactive: true
        });

        const mainContainer = new St.BoxLayout({
            vertical: true,
            style_class: 'portfolio-container'
        });

        // Header
        const header = new St.BoxLayout({
            style_class: 'portfolio-header'
        });

        const titleContainer = new St.BoxLayout({
            style_class: 'title-container'
        });
        
        const title = new St.Label({
            text: 'PORTFOLIO TRACKER',
            style_class: 'portfolio-title'
        });
        titleContainer.add_child(title);

        const rightContainer = new St.BoxLayout({
            style_class: 'right-container'
        });

        // Search
        const searchContainer = new St.BoxLayout({
            style_class: 'search-container'
        });

        this._searchButton = new St.Button({
            style_class: 'search-button',
            reactive: true
        });

        const searchButtonContent = new St.BoxLayout({
            style_class: 'search-button-content'
        });

        this._searchEntry = new St.Entry({
            style_class: 'search-entry',
            visible: false
        });

        this._setupSearchEntry();
        searchButtonContent.add_child(this._searchEntry);

        this._searchIcon = new St.Icon({ 
            icon_name: 'edit-find-symbolic',
            style_class: 'search-icon'
        });
        searchButtonContent.add_child(this._searchIcon);

        this._searchButton.add_child(searchButtonContent);

        this._searchButton.connect('button-press-event', () => {
            this._toggleSearchInput();
            return Clutter.EVENT_STOP;
        });

        // Edit Mode
        const editHeaderContainer = new St.BoxLayout({
            style_class: 'edit-header-container'
        });

        this._editModeButton = new St.Button({
            style_class: 'edit-mode-button'
        });

        this._editModeIcon = new St.Icon({ 
            icon_name: 'edit-symbolic',
            style_class: 'edit-mode-icon'
        });

        this._editModeButton.add_child(this._editModeIcon);
        this._editModeButton.connect('clicked', () => {
            this._toggleEditMode();
        });

        searchContainer.add_child(this._searchButton);
        editHeaderContainer.add_child(this._editModeButton);

        rightContainer.add_child(searchContainer);
        rightContainer.add_child(editHeaderContainer);

        header.add_child(titleContainer);
        header.add_child(rightContainer);

        // Content
        const contentArea = new St.BoxLayout({
            vertical: true,
            style_class: 'portfolio-content'
        });

        // Stats Cards
        const statsCards = new St.BoxLayout({
            style_class: 'stats-cards'
        });

        this._totalValueCard = this._createStatCard('TOTAL VALUE', '$0.00', 'money-bag-symbolic');
        this._totalProfitCard = this._createStatCard('PROFIT/LOSS', '0.00%', 'trend-up-symbolic');
        this._totalInvestmentCard = this._createStatCard('INVESTED', '$0.00', 'investment-symbolic');

        statsCards.add_child(this._totalValueCard);
        statsCards.add_child(this._totalProfitCard);
        statsCards.add_child(this._totalInvestmentCard);

        // Assets Table
        const assetsSection = new St.BoxLayout({
            vertical: true,
            style_class: 'assets-section'
        });

        const assetsHeader = new St.BoxLayout({
            style_class: 'assets-header'
        });
    
        this._createHeaderLabel(assetsHeader, 'ASSET', 'asset-name', 90);
        this._createHeaderLabel(assetsHeader, 'PRICE', 'asset-price', 80);
        this._createHeaderLabel(assetsHeader, 'QUANTITY', 'asset-quantity', 70);
        this._createHeaderLabel(assetsHeader, 'VALUE', 'asset-value', 90);
        this._createHeaderLabel(assetsHeader, 'P&L', 'asset-profitability', 70);

        this._assetsContainer = new St.BoxLayout({
            vertical: true,
            style_class: 'assets-container'
        });
    
        assetsSection.add_child(assetsHeader);
        assetsSection.add_child(this._assetsContainer);

        // Chart Section
        const chartSection = new St.BoxLayout({
            vertical: true,
            style_class: 'chart-section'
        });

        this._chartArea = new St.DrawingArea({
            style_class: 'chart-area',
            width: 200,
            height: 200
        });
    
        this._chartArea.connect('repaint', (area) => {
            this._drawChart(area);
        });

        this._chartLegend = new St.BoxLayout({
            style_class: 'chart-legend'
        });

        chartSection.add_child(this._chartArea);
        chartSection.add_child(this._chartLegend);

        // Assemble everything
        contentArea.add_child(statsCards);
        contentArea.add_child(assetsSection);
        contentArea.add_child(chartSection);
        
        mainContainer.add_child(header);
        mainContainer.add_child(contentArea);
        this._window.add_child(mainContainer);
        
        this._repositionWindow();
    
        this._window.connect('button-press-event', () => {
            return Clutter.EVENT_STOP;
        });

        this._window.connect('key-press-event', (actor, event) => {
            const key = event.get_key_symbol();
            if (key === Clutter.KEY_Escape) {
                this._hidePortfolioWindow();
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        });

        this._animateChart();
    }

    _createHeaderLabel(container, text, styleClass, width) {
        const label = new St.Label({
            text: text,
            style_class: `assets-header-label ${styleClass}`
        });
        label.set_width(width);
        container.add_child(label);
    }

    _createStatCard(title, value, iconName) {
        const card = new St.Button({
            style_class: 'stat-card',
            reactive: true
        });

        const cardContent = new St.BoxLayout({
            vertical: true,
            style_class: 'stat-card-content'
        });

        const icon = new St.Icon({
            icon_name: iconName,
            style_class: 'stat-card-icon'
        });

        const titleLabel = new St.Label({
            text: title,
            style_class: 'stat-card-title'
        });

        const valueLabel = new St.Label({
            text: value,
            style_class: 'stat-card-value'
        });

        cardContent.add_child(icon);
        cardContent.add_child(titleLabel);
        cardContent.add_child(valueLabel);
        card.add_child(cardContent);

        return card;
    }

    _animateChart() {
        this._chartAnimationProgress = 0;
        const animate = () => {
            if (this._chartAnimationProgress < 1 && this._chartArea) {
                this._chartAnimationProgress += 0.05;
                this._chartArea.queue_repaint();
                GLib.timeout_add(GLib.PRIORITY_DEFAULT, 30, () => {
                    animate();
                    return GLib.SOURCE_REMOVE;
                });
            }
        };
        animate();
    }

    _repositionWindow() {
        if (!this._window || !this._button) return;
        try {
            const [buttonX, buttonY] = this._button.get_transformed_position();
            const panelHeight = Main.panel.height;
            const monitor = Main.layoutManager.primaryMonitor;
            const x = Math.min(buttonX, monitor.width - 450);
            const y = buttonY + panelHeight + 5;
            this._window.set_position(x, y);
        } catch (error) {
            this._window.set_position(100, 100);
        }
    }

    _askForPurchaseDetails(asset) {
        const dialog = new St.Widget({
            style_class: 'purchase-dialog',
            reactive: true
        });

        const container = new St.BoxLayout({
            vertical: true,
            style_class: 'purchase-container'
        });

        const message = new St.Label({
            text: `Add ${asset.symbol}`,
            style_class: 'purchase-message'
        });

        const quantityContainer = new St.BoxLayout({
            style_class: 'purchase-field-container'
        });
        quantityContainer.add_child(new St.Label({
            text: 'Quantity:',
            style_class: 'purchase-label'
        }));
        const quantityEntry = new St.Entry({
            text: '1',
            style_class: 'purchase-entry'
        });
        quantityContainer.add_child(quantityEntry);

        const priceContainer = new St.BoxLayout({
            style_class: 'purchase-field-container'
        });
        priceContainer.add_child(new St.Label({
            text: 'Purchase Price:',
            style_class: 'purchase-label'
        }));
        const priceEntry = new St.Entry({
            text: asset.price.toFixed(2),
            style_class: 'purchase-entry'
        });
        priceContainer.add_child(priceEntry);

        const buttonContainer = new St.BoxLayout({
            style_class: 'purchase-buttons'
        });

        const addButton = new St.Button({
            label: 'ADD',
            style_class: 'purchase-add-button'
        });

        const cancelButton = new St.Button({
            label: 'CANCEL',
            style_class: 'purchase-cancel-button'
        });

        addButton.connect('clicked', () => {
            const quantity = parseInt(quantityEntry.get_text()) || 1;
            const purchasePrice = parseFloat(priceEntry.get_text()) || asset.price;
            
            if (quantity > 0 && purchasePrice > 0) {
                const newAsset = {
                    symbol: asset.symbol,
                    price: asset.price,
                    currentPrice: asset.price,
                    purchasePrice: purchasePrice,
                    quantity: quantity,
                    name: asset.name,
                    color: this._getRandomColor()
                };
                
                const existingIndex = this._assetsData.findIndex(a => a.symbol === asset.symbol);
                if (existingIndex >= 0) {
                    const existingAsset = this._assetsData[existingIndex];
                    const totalQuantity = existingAsset.quantity + quantity;
                    const averagePrice = ((existingAsset.purchasePrice * existingAsset.quantity) + 
                                        (purchasePrice * quantity)) / totalQuantity;
                    
                    existingAsset.quantity = totalQuantity;
                    existingAsset.purchasePrice = averagePrice;
                } else {
                    this._assetsData.push(newAsset);
                }
                
                this._updatePortfolioData();
                this._saveAssetsData();
                Main.layoutManager.removeChrome(dialog);
                Main.notify(`Added ${quantity} ${asset.symbol}`);
            } else {
                Main.notify('Please enter valid values');
            }
        });

        cancelButton.connect('clicked', () => {
            Main.layoutManager.removeChrome(dialog);
        });

        const handleEnter = (actor, event) => {
            const key = event.get_key_symbol();
            if (key === Clutter.KEY_Return || key === Clutter.KEY_KP_Enter) {
                addButton.emit('clicked');
                return Clutter.EVENT_STOP;
            }
            return Clutter.EVENT_PROPAGATE;
        };

        quantityEntry.get_clutter_text().connect('key-press-event', handleEnter);
        priceEntry.get_clutter_text().connect('key-press-event', handleEnter);

        buttonContainer.add_child(addButton);
        buttonContainer.add_child(cancelButton);

        container.add_child(message);
        container.add_child(quantityContainer);
        container.add_child(priceContainer);
        container.add_child(buttonContainer);
        dialog.add_child(container);

        const monitor = Main.layoutManager.primaryMonitor;
        dialog.set_position(
            Math.floor((monitor.width - 300) / 2),
            Math.floor((monitor.height - 200) / 2)
        );

        Main.layoutManager.addChrome(dialog);
        dialog.show();
        quantityEntry.grab_key_focus();
    }

    _getRandomColor() {
        const colors = [
            '#32FC32', '#4ECDC4', '#45B7D1', '#96CEB4', 
            '#FECA57', '#FF9FF3', '#54A0FF', '#5F27CD'
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    _calculateProfitability(currentPrice, purchasePrice) {
        if (!purchasePrice || purchasePrice === 0) return 0;
        return ((currentPrice - purchasePrice) / purchasePrice) * 100;
    }

    _updatePortfolioData() {
        if (!this._assetsContainer) return;
    
        this._assetsContainer.destroy_all_children();
        if (this._chartLegend) {
            this._chartLegend.destroy_all_children();
        }
    
        let totalValue = 0;
        let totalInvestment = 0;
        let totalProfit = 0;
    
        this._assetsData.forEach(asset => {
            if (!asset.purchasePrice) asset.purchasePrice = asset.price || 0;
            if (!asset.quantity) asset.quantity = 1;

            const assetValue = asset.price * asset.quantity;
            const assetInvestment = asset.purchasePrice * asset.quantity;
            const assetProfit = assetValue - assetInvestment;

            totalValue += assetValue;
            totalInvestment += assetInvestment;
            totalProfit += assetProfit;
        });

        const totalProfitability = totalInvestment > 0 ? (totalProfit / totalInvestment) * 100 : 0;

        // Update stat cards
        if (this._totalValueCard) {
            const valueLabel = this._totalValueCard.get_children()[0].get_children()[2];
            valueLabel.set_text(`$${totalValue.toFixed(2)}`);
        }

        if (this._totalProfitCard) {
            const profitLabel = this._totalProfitCard.get_children()[0].get_children()[2];
            profitLabel.set_text(`${totalProfitability.toFixed(2)}%`);
            profitLabel.style_class = `stat-card-value ${totalProfitability >= 0 ? 'profit-positive' : 'profit-negative'}`;
        }

        if (this._totalInvestmentCard) {
            const investmentLabel = this._totalInvestmentCard.get_children()[0].get_children()[2];
            investmentLabel.set_text(`$${totalInvestment.toFixed(2)}`);
        }

        // Update assets list
        this._assetsData.forEach((asset, index) => {
            const assetValue = asset.price * asset.quantity;
            const percentage = totalValue > 0 ? (assetValue / totalValue * 100) : 0;
            const profitability = this._calculateProfitability(asset.price, asset.purchasePrice);

            const assetRow = new St.Button({
                style_class: "asset-row",
                reactive: true
            });

            const rowContent = new St.BoxLayout({
                style_class: 'asset-row-content'
            });

            // Symbol with color indicator
            const symbolContainer = new St.BoxLayout({
                style_class: 'symbol-container'
            });

            const colorIndicator = new St.Widget({
                style_class: 'color-indicator'
            });
            colorIndicator.set_style(`background-color: ${asset.color};`);

            const symbolLabel = new St.Label({
                text: asset.symbol,
                style_class: 'row-symbol'
            });

            symbolContainer.add_child(colorIndicator);
            symbolContainer.add_child(symbolLabel);
            rowContent.add_child(symbolContainer);

            // Price
            rowContent.add_child(new St.Label({
                text: `$${asset.price.toFixed(2)}`,
                style_class: 'row-price'
            }));

            // Quantity
            if (this._isEditMode) {
                const quantityEntry = new St.Entry({
                    text: asset.quantity.toString(),
                    style_class: 'edit-entry-field'
                });
            
                quantityEntry.get_clutter_text().connect('text-changed', () => {
                    const newQuantity = parseInt(quantityEntry.get_text()) || asset.quantity;
                    asset.quantity = newQuantity;
                    this._updatePortfolioData();
                });
            
                rowContent.add_child(quantityEntry);
            } else {
                rowContent.add_child(new St.Label({
                    text: asset.quantity.toString(),
                    style_class: 'row-quantity'
                }));
            }

            // Value
            rowContent.add_child(new St.Label({
                text: `$${assetValue.toFixed(2)}`,
                style_class: 'row-value'
            }));

            // Profitability
            const profitabilityColor = profitability >= 0 ? 'profit-positive' : 'profit-negative';
            rowContent.add_child(new St.Label({
                text: `${profitability.toFixed(2)}%`,
                style_class: `row-profitability ${profitabilityColor}`
            }));

            // Delete button in edit mode
            if (this._isEditMode) {
                const deleteButton = new St.Button({
                    style_class: 'delete-button'
                });

                const deleteIcon = new St.Icon({ 
                    icon_name: 'edit-delete-symbolic',
                    style_class: 'delete-icon'
                });

                deleteButton.add_child(deleteIcon);
                deleteButton.connect('clicked', () => {
                    this._deleteAsset(index);
                });

                rowContent.add_child(deleteButton);
            }

            assetRow.add_child(rowContent);
            this._assetsContainer.add_child(assetRow);

            // Chart legend
            if (this._chartLegend) {
                const legendItem = new St.Button({
                    style_class: 'legend-item',
                    reactive: true
                });

                const legendContent = new St.BoxLayout({
                    style_class: 'legend-content'
                });

                const colorBox = new St.Widget({
                    style_class: 'legend-color-box'
                });
                colorBox.set_style(`background-color: ${asset.color};`);

                const legendLabel = new St.Label({
                    text: `${asset.symbol} (${percentage.toFixed(1)}%)`,
                    style_class: 'legend-label'
                });

                legendContent.add_child(colorBox);
                legendContent.add_child(legendLabel);
                legendItem.add_child(legendContent);

                legendItem.connect('clicked', () => {
                    this._currentHoverIndex = index;
                    this._chartArea.queue_repaint();
                });

                this._chartLegend.add_child(legendItem);
            }
        });

        this._animateChart();
    }

    _deleteAsset(index) {
        if (index < 0 || index >= this._assetsData.length) return;
    
        const asset = this._assetsData[index];
    
        const dialog = new St.Widget({
            style_class: 'confirm-dialog',
            reactive: true
        });

        const container = new St.BoxLayout({
            vertical: true,
            style_class: 'confirm-container'
        });

        const message = new St.Label({
            text: `Delete ${asset.symbol}?`,
            style_class: 'confirm-message'
        });

        const buttonContainer = new St.BoxLayout({
            style_class: 'confirm-buttons'
        });

        const confirmButton = new St.Button({
            label: 'DELETE',
            style_class: 'confirm-yes-button'
        });

        const cancelButton = new St.Button({
            label: 'CANCEL',
            style_class: 'confirm-cancel-button'
        });

        confirmButton.connect('clicked', () => {
            this._assetsData.splice(index, 1);
            this._updatePortfolioData();
            this._saveAssetsData();
            Main.layoutManager.removeChrome(dialog);
            Main.notify(`Deleted ${asset.symbol}`);
        });

        cancelButton.connect('clicked', () => {
            Main.layoutManager.removeChrome(dialog);
        });

        buttonContainer.add_child(confirmButton);
        buttonContainer.add_child(cancelButton);

        container.add_child(message);
        container.add_child(buttonContainer);
        dialog.add_child(container);

        const monitor = Main.layoutManager.primaryMonitor;
        dialog.set_position(
            Math.floor((monitor.width - 280) / 2),
            Math.floor((monitor.height - 120) / 2)
        );

        Main.layoutManager.addChrome(dialog);
        dialog.show();
    }

    _drawChart(area) {
        if (this._assetsData.length === 0) return;
        
        const cr = area.get_context();
        const width = area.get_width();
        const height = area.get_height();
        const radius = Math.min(width, height) / 2 - 10;
        const centerX = width / 2;
        const centerY = height / 2;
        
        let totalValue = 0;
        this._assetsData.forEach(asset => {
            totalValue += asset.price * asset.quantity;
        });
        
        if (totalValue === 0) return;
        
        let currentAngle = -Math.PI / 2;
        
        this._assetsData.forEach((asset, index) => {
            const assetValue = asset.price * asset.quantity;
            const angle = (assetValue / totalValue) * 2 * Math.PI * this._chartAnimationProgress;
            
            if (angle > 0) {
                cr.arc(centerX, centerY, radius, currentAngle, currentAngle + angle);
                cr.lineTo(centerX, centerY);
                cr.closePath();
                
                const color = asset.color || '#32FC32';
                const r = parseInt(color.substr(1, 2), 16) / 255;
                const g = parseInt(color.substr(3, 2), 16) / 255;
                const b = parseInt(color.substr(5, 2), 16) / 255;
                
                const isHovered = this._currentHoverIndex === index;
                const alpha = isHovered ? 1 : 0.8;
                
                cr.setSourceRGBA(r, g, b, alpha);
                cr.fill();
                
                currentAngle += angle;
            }
        });
    }

    disable() {
        this._hidePortfolioWindow();
        this._hideSuggestions();
        
        if (this._priceUpdateInterval) {
            GLib.Source.remove(this._priceUpdateInterval);
        }
        
        if (this._button) {
            this._button.destroy();
            this._button = null;
        }
        
        this._isWindowVisible = false;
    }
}